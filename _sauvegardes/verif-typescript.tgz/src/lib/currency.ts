/**
 * Conversion FCFA → euro. Le franc CFA est arrimé à l'euro à taux fixe :
 * les montants en euros sont toujours calculés, jamais saisis dans l'admin.
 */
export const XAF_PAR_EUR = 655.957

export function fcfaVersEuro(montantFcfa: number): number {
  return Math.round(montantFcfa / XAF_PAR_EUR)
}

const formatFcfa = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 })

/** « 40 000 FCFA » */
export function formaterFcfa(montant: number): string {
  return `${formatFcfa.format(montant)} FCFA`
}

/** « ≈ 61 € » */
export function formaterEquivalentEuro(montantFcfa: number): string {
  return `≈ ${formatFcfa.format(fcfaVersEuro(montantFcfa))} €`
}
