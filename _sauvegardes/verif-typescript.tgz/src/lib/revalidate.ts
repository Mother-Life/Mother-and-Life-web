import type {
  CollectionAfterChangeHook,
  CollectionAfterDeleteHook,
  GlobalAfterChangeHook,
} from 'payload'
import { revalidatePath } from 'next/cache'

/**
 * Après chaque publication dans l'admin, on invalide le cache du site
 * pour que la modification apparaisse sans nouveau déploiement.
 * Le site est petit : on revalide toute la mise en page plutôt qu'une route précise.
 * Hors du contexte Next (seed, CLI Payload), l'appel échoue sans conséquence.
 * Pour un import en masse, passer `context: { disableRevalidate: true }`.
 */
function revalidateSite() {
  try {
    revalidatePath('/', 'layout')
  } catch {
    // Exécuté hors de Next.js (script, migration) : rien à invalider.
  }
}

export const revalidateAfterChange: CollectionAfterChangeHook = ({ doc, req }) => {
  if (!req.context?.disableRevalidate) revalidateSite()
  return doc
}

export const revalidateAfterDelete: CollectionAfterDeleteHook = ({ doc, req }) => {
  if (!req.context?.disableRevalidate) revalidateSite()
  return doc
}

export const revalidateGlobalAfterChange: GlobalAfterChangeHook = ({ doc, req }) => {
  if (!req.context?.disableRevalidate) revalidateSite()
  return doc
}
