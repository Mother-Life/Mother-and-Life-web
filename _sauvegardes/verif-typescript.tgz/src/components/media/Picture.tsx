import Image from 'next/image'
import { cn } from '@/lib/utils'

type PictureProps = {
  src: string
  alt: string
  width: number
  height: number
  className?: string
  priority?: boolean
  sizes?: string
  /** Repousse le chargement hors du premier ecran. Ignore si `priority`. */
  loading?: 'eager' | 'lazy'
}

export function Picture({
  src,
  alt,
  width,
  height,
  className,
  priority = false,
  sizes = '100vw',
  loading,
}: PictureProps) {
  return (
    <Image
      src={src}
      alt={alt}
      width={width}
      height={height}
      priority={priority}
      loading={priority ? undefined : loading}
      sizes={sizes}
      className={cn('h-full w-full object-cover', className)}
    />
  )
}
