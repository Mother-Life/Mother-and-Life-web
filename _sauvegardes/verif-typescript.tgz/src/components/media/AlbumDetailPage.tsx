'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import Link from 'next/link'
import { Picture } from '@/components/media/Picture'
import { Container } from '@/components/ui/Container'
import { Section } from '@/components/ui/Section'
import { Heading } from '@/components/ui/Heading'
import { sampleAlbums } from '@/data/defaults'
import { getAlbumImage } from '@/lib/assets/images'
import type { Locale } from '@/lib/i18n/config'

export function AlbumDetailPage({ locale, slug }: { locale: Locale; slug: string }) {
  const album = sampleAlbums.find((a) => a.slug === slug)
  const prefix = locale === 'fr' ? '' : '/en'
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null)
  const isFr = locale === 'fr'
  const cover = getAlbumImage(slug)
  const dialogRef = useRef<HTMLDivElement>(null)
  const openerRef = useRef<HTMLElement | null>(null)
  const touchStartX = useRef<number | null>(null)

  const photos = Array.from({ length: album?.nbPhotos ?? 0 }, (_, i) => ({
    id: i,
    alt: `${album?.titre} \u2014 photo ${i + 1}`,
  }))

  const closeLightbox = useCallback(() => setLightboxIndex(null), [])
  const nextPhoto = useCallback(() => {
    setLightboxIndex((current) => (current === null ? current : (current + 1) % photos.length))
  }, [photos.length])
  const prevPhoto = useCallback(() => {
    setLightboxIndex((current) =>
      current === null ? current : (current - 1 + photos.length) % photos.length,
    )
  }, [photos.length])

  const openLightbox = (index: number, event: React.MouseEvent<HTMLButtonElement>) => {
    openerRef.current = event.currentTarget
    setLightboxIndex(index)
  }

  // Clavier, verrouillage du defilement, piegeage du focus et restitution du
  // focus a la vignette d'origine a la fermeture.
  useEffect(() => {
    if (lightboxIndex === null) return

    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    dialogRef.current?.focus()

    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeLightbox()
        return
      }
      if (e.key === 'ArrowRight') nextPhoto()
      if (e.key === 'ArrowLeft') prevPhoto()
      if (e.key !== 'Tab') return

      const focusables = dialogRef.current?.querySelectorAll<HTMLElement>('button, [href], [tabindex]:not([tabindex="-1"])')
      if (!focusables?.length) return
      const first = focusables[0]
      const last = focusables[focusables.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }

    window.addEventListener('keydown', handler)
    return () => {
      window.removeEventListener('keydown', handler)
      document.body.style.overflow = previousOverflow
      openerRef.current?.focus()
    }
  }, [lightboxIndex, closeLightbox, nextPhoto, prevPhoto])

  if (!album) return null

  return (
    <Section bg="white">
      <Container>
        <nav className="mb-6 text-[14px] text-gris-600" aria-label={isFr ? "Fil d'Ariane" : 'Breadcrumb'}>
          <Link href={`${prefix}/albums`} className="hover:text-rose-700">
            Albums
          </Link>
          {' / '}
          <span>{album.titre}</span>
        </nav>
        <Heading level={1} className="mb-2">
          {album.titre}
        </Heading>
        <p className="mb-2 text-gris-600">{album.resume}</p>
        <p className="mb-8 text-[14px] text-gris-600">
          {album.annee}
          {' \u00b7 '}
          {album.nbPhotos} photos
        </p>

        <div className="columns-2 gap-4 md:columns-3">
          {photos.map((photo, i) => (
            <button
              key={photo.id}
              type="button"
              onClick={(event) => openLightbox(i, event)}
              className="mb-4 w-full break-inside-avoid overflow-hidden rounded-[8px] bg-gris-100 aspect-[4/3]"
              aria-label={photo.alt}
            >
              <Picture
                src={cover.src}
                alt={photo.alt}
                width={cover.width}
                height={cover.height}
                loading="lazy"
                sizes="(max-width: 768px) 50vw, 320px"
              />
            </button>
          ))}
        </div>
      </Container>

      {lightboxIndex !== null && (
        <div
          ref={dialogRef}
          tabIndex={-1}
          role="dialog"
          aria-modal="true"
          aria-label={photos[lightboxIndex]?.alt}
          className="fixed inset-0 z-[300] flex items-center justify-center bg-nuit/90"
          onTouchStart={(e) => {
            touchStartX.current = e.touches[0]?.clientX ?? null
          }}
          onTouchEnd={(e) => {
            const start = touchStartX.current
            const end = e.changedTouches[0]?.clientX
            touchStartX.current = null
            if (start == null || end == null) return
            const delta = end - start
            if (Math.abs(delta) > 48) {
              if (delta < 0) nextPhoto()
              else prevPhoto()
            }
          }}
        >
          <button
            type="button"
            onClick={closeLightbox}
            className="absolute right-4 top-4 text-3xl text-white"
            aria-label={isFr ? 'Fermer' : 'Close'}
          >
            <span aria-hidden="true">&times;</span>
          </button>
          <button
            type="button"
            onClick={prevPhoto}
            className="absolute left-4 text-4xl text-white"
            aria-label={isFr ? 'Pr\u00e9c\u00e9dent' : 'Previous'}
          >
            <span aria-hidden="true">&lsaquo;</span>
          </button>
          <div className="mx-16 aspect-[4/3] w-full max-w-4xl overflow-hidden rounded-[12px] bg-nuit">
            <Picture
              src={cover.src}
              alt={photos[lightboxIndex]?.alt ?? cover.alt[locale]}
              width={cover.width}
              height={cover.height}
              sizes="90vw"
            />
          </div>
          <button
            type="button"
            onClick={nextPhoto}
            className="absolute right-4 text-4xl text-white"
            aria-label={isFr ? 'Suivant' : 'Next'}
          >
            <span aria-hidden="true">&rsaquo;</span>
          </button>
          <p className="absolute bottom-6 text-center text-white">{photos[lightboxIndex]?.alt}</p>
        </div>
      )}
    </Section>
  )
}
